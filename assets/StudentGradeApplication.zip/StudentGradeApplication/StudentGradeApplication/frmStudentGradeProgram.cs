﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentGradeApplication
{
    public partial class frmStudentGradeProgram : Form
    {
        public frmStudentGradeProgram()
        {
            InitializeComponent();
        }

        private void Generate_Average_Button_Click(object sender, EventArgs e)
        {
            double failingGrade = 75;
            double engGrade = Double.Parse(txtbx_English.Text.ToString());
            double mathGrade = Double.Parse(txtbx_Math.Text.ToString());
            double sciGrade = Double.Parse(txtbx_Science.Text.ToString());
            double filGrade = Double.Parse(txtbx_Filipino.Text.ToString());
            double hisGrade = Double.Parse(txtbx_History.Text.ToString());
            
            double avrg = (engGrade + mathGrade + sciGrade + filGrade + hisGrade) / 5;
            string name = txtbx_Name.Text.ToString();
     
            if (avrg >= failingGrade)
            {
                PassResult_Label.Text = "The student passed!";
                PassResult_Label.Location = new Point(190, 115);
                Result_Label.Text = "The general average of " +name + " is " + avrg;
                
            }
            else {
                PassResult_Label.Text = "The student did not pass.";
                PassResult_Label.Location = new Point(190, 115);
                Result_Label.Text = "The general average of " + name + " is " + avrg;

            }

        }

        private void frmStudentGradeProgram_Load(object sender, EventArgs e)
        {

        }
    }
}
