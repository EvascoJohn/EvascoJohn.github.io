﻿namespace StudentGradeApplication
{
    partial class frmStudentGradeProgram
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Name_Label = new System.Windows.Forms.Label();
            this.txtbx_Name = new System.Windows.Forms.TextBox();
            this.English_Label = new System.Windows.Forms.Label();
            this.Science_Label = new System.Windows.Forms.Label();
            this.Filipino_Label = new System.Windows.Forms.Label();
            this.Math_Label = new System.Windows.Forms.Label();
            this.History_Label = new System.Windows.Forms.Label();
            this.txtbx_Science = new System.Windows.Forms.TextBox();
            this.txtbx_Filipino = new System.Windows.Forms.TextBox();
            this.txtbx_Math = new System.Windows.Forms.TextBox();
            this.txtbx_English = new System.Windows.Forms.TextBox();
            this.txtbx_History = new System.Windows.Forms.TextBox();
            this.Generate_Average_Button = new System.Windows.Forms.Button();
            this.Result_Label = new System.Windows.Forms.Label();
            this.PassResult_Label = new System.Windows.Forms.Label();
            this.Grade_Label = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Name_Label
            // 
            this.Name_Label.AutoSize = true;
            this.Name_Label.Location = new System.Drawing.Point(12, 12);
            this.Name_Label.Name = "Name_Label";
            this.Name_Label.Size = new System.Drawing.Size(38, 13);
            this.Name_Label.TabIndex = 1;
            this.Name_Label.Text = "Name:";
            // 
            // txtbx_Name
            // 
            this.txtbx_Name.Location = new System.Drawing.Point(65, 12);
            this.txtbx_Name.Name = "txtbx_Name";
            this.txtbx_Name.Size = new System.Drawing.Size(277, 20);
            this.txtbx_Name.TabIndex = 2;
            // 
            // English_Label
            // 
            this.English_Label.AutoSize = true;
            this.English_Label.Location = new System.Drawing.Point(12, 64);
            this.English_Label.Name = "English_Label";
            this.English_Label.Size = new System.Drawing.Size(44, 13);
            this.English_Label.TabIndex = 3;
            this.English_Label.Text = "English:";
            // 
            // Science_Label
            // 
            this.Science_Label.AutoSize = true;
            this.Science_Label.Location = new System.Drawing.Point(12, 120);
            this.Science_Label.Name = "Science_Label";
            this.Science_Label.Size = new System.Drawing.Size(49, 13);
            this.Science_Label.TabIndex = 4;
            this.Science_Label.Text = "Science:";
            // 
            // Filipino_Label
            // 
            this.Filipino_Label.AutoSize = true;
            this.Filipino_Label.Location = new System.Drawing.Point(12, 153);
            this.Filipino_Label.Name = "Filipino_Label";
            this.Filipino_Label.Size = new System.Drawing.Size(42, 13);
            this.Filipino_Label.TabIndex = 5;
            this.Filipino_Label.Text = "Filipino:";
            // 
            // Math_Label
            // 
            this.Math_Label.AutoSize = true;
            this.Math_Label.Location = new System.Drawing.Point(12, 94);
            this.Math_Label.Name = "Math_Label";
            this.Math_Label.Size = new System.Drawing.Size(34, 13);
            this.Math_Label.TabIndex = 6;
            this.Math_Label.Text = "Math:";
            // 
            // History_Label
            // 
            this.History_Label.AutoSize = true;
            this.History_Label.Location = new System.Drawing.Point(12, 188);
            this.History_Label.Name = "History_Label";
            this.History_Label.Size = new System.Drawing.Size(42, 13);
            this.History_Label.TabIndex = 7;
            this.History_Label.Text = "History:";
            // 
            // txtbx_Science
            // 
            this.txtbx_Science.Location = new System.Drawing.Point(65, 120);
            this.txtbx_Science.Name = "txtbx_Science";
            this.txtbx_Science.Size = new System.Drawing.Size(52, 20);
            this.txtbx_Science.TabIndex = 8;
            // 
            // txtbx_Filipino
            // 
            this.txtbx_Filipino.Location = new System.Drawing.Point(65, 150);
            this.txtbx_Filipino.Name = "txtbx_Filipino";
            this.txtbx_Filipino.Size = new System.Drawing.Size(52, 20);
            this.txtbx_Filipino.TabIndex = 9;
            // 
            // txtbx_Math
            // 
            this.txtbx_Math.Location = new System.Drawing.Point(65, 91);
            this.txtbx_Math.Name = "txtbx_Math";
            this.txtbx_Math.Size = new System.Drawing.Size(52, 20);
            this.txtbx_Math.TabIndex = 10;
            // 
            // txtbx_English
            // 
            this.txtbx_English.Location = new System.Drawing.Point(65, 61);
            this.txtbx_English.Name = "txtbx_English";
            this.txtbx_English.Size = new System.Drawing.Size(52, 20);
            this.txtbx_English.TabIndex = 11;
            // 
            // txtbx_History
            // 
            this.txtbx_History.Location = new System.Drawing.Point(65, 185);
            this.txtbx_History.Name = "txtbx_History";
            this.txtbx_History.Size = new System.Drawing.Size(52, 20);
            this.txtbx_History.TabIndex = 12;
            // 
            // Generate_Average_Button
            // 
            this.Generate_Average_Button.Location = new System.Drawing.Point(12, 223);
            this.Generate_Average_Button.Name = "Generate_Average_Button";
            this.Generate_Average_Button.Size = new System.Drawing.Size(104, 30);
            this.Generate_Average_Button.TabIndex = 13;
            this.Generate_Average_Button.Text = "Generate Average";
            this.Generate_Average_Button.UseVisualStyleBackColor = true;
            this.Generate_Average_Button.Click += new System.EventHandler(this.Generate_Average_Button_Click);
            // 
            // Result_Label
            // 
            this.Result_Label.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Result_Label.AutoSize = true;
            this.Result_Label.Location = new System.Drawing.Point(154, 140);
            this.Result_Label.MaximumSize = new System.Drawing.Size(200, 0);
            this.Result_Label.Name = "Result_Label";
            this.Result_Label.Size = new System.Drawing.Size(0, 13);
            this.Result_Label.TabIndex = 14;
            this.Result_Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PassResult_Label
            // 
            this.PassResult_Label.AutoSize = true;
            this.PassResult_Label.Location = new System.Drawing.Point(162, 122);
            this.PassResult_Label.Name = "PassResult_Label";
            this.PassResult_Label.Size = new System.Drawing.Size(154, 13);
            this.PassResult_Label.TabIndex = 15;
            this.PassResult_Label.Text = "Please Enter Student\'s Grades.";
            // 
            // Grade_Label
            // 
            this.Grade_Label.AutoSize = true;
            this.Grade_Label.Location = new System.Drawing.Point(71, 39);
            this.Grade_Label.Name = "Grade_Label";
            this.Grade_Label.Size = new System.Drawing.Size(41, 13);
            this.Grade_Label.TabIndex = 16;
            this.Grade_Label.Text = "Grades";
            // 
            // frmStudentGradeProgram
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(380, 270);
            this.Controls.Add(this.Grade_Label);
            this.Controls.Add(this.PassResult_Label);
            this.Controls.Add(this.Result_Label);
            this.Controls.Add(this.Generate_Average_Button);
            this.Controls.Add(this.txtbx_Name);
            this.Controls.Add(this.txtbx_English);
            this.Controls.Add(this.txtbx_Math);
            this.Controls.Add(this.txtbx_Science);
            this.Controls.Add(this.txtbx_Filipino);
            this.Controls.Add(this.txtbx_History);
            this.Controls.Add(this.History_Label);
            this.Controls.Add(this.Math_Label);
            this.Controls.Add(this.Filipino_Label);
            this.Controls.Add(this.Science_Label);
            this.Controls.Add(this.English_Label);
            this.Controls.Add(this.Name_Label);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmStudentGradeProgram";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Student Grade Application";
            this.Load += new System.EventHandler(this.frmStudentGradeProgram_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtbx_Name;
        private System.Windows.Forms.Label English_Label;
        private System.Windows.Forms.Label Science_Label;
        private System.Windows.Forms.Label Filipino_Label;
        private System.Windows.Forms.Label Math_Label;
        private System.Windows.Forms.Label History_Label;
        public System.Windows.Forms.Label Name_Label;
        private System.Windows.Forms.TextBox txtbx_Science;
        private System.Windows.Forms.TextBox txtbx_Filipino;
        private System.Windows.Forms.TextBox txtbx_Math;
        private System.Windows.Forms.TextBox txtbx_English;
        private System.Windows.Forms.TextBox txtbx_History;
        private System.Windows.Forms.Button Generate_Average_Button;
        private System.Windows.Forms.Label Result_Label;
        private System.Windows.Forms.Label PassResult_Label;
        private System.Windows.Forms.Label Grade_Label;
    }
}

