﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Text;

namespace _07_TaskPerformance_GUI_Evasco
{
    public partial class Form1 : Form
    {
        string image;
        int oldIndex;
        int currentIndex = 0;
        int index;
        string correctWord;
        StringBuilder guessWord;
        ArrayList blankIndexes = new ArrayList();
        ArrayList imageLocations = new ArrayList{ "cow.png", "house.png", "idea.png", "car.png", "red.png"};
        ArrayList words = new ArrayList { "Cow", "House", "Idea", "Car", "red"};

        public Form1()
        {
            InitializeComponent();
            GenerateGame();
        }

        public void changeGuessWordLabel(string word)
        {
            lbl_strippedWord.Text = word;
        }

        public void generateRandomNumbersToArrayList(int n, ArrayList arraylist)
        {
            Random randomNumGen = new Random();
            int lttrsToRemove = (int)Math.Round((double)n / 2);

            for (int loop = 0; loop < lttrsToRemove; loop += 1)
            {
                int number = randomNumGen.Next(0, n);
                if (arraylist.Contains(number) == false)
                {
                    arraylist.Add(number);
                }
            }
            arraylist.Sort();
        }



        public void letterTracker(char letter, ArrayList arraylist, StringBuilder word)
        {
            if (currentIndex < 0)
            {
                currentIndex = 0;
            }
            else if (currentIndex > arraylist.Count-1)
            {
                currentIndex = arraylist.Count;
            }
            if (currentIndex >= 0 && currentIndex < arraylist.Count)
            {
                int guessWordIndex = (int)arraylist[currentIndex];
                word[guessWordIndex] = letter;
            }
        }


        public void getRandomWord(ArrayList arraylist)
        {
            Random randInt = new Random();
            int number = randInt.Next(0, arraylist.Count);
            int x = number;
            guessWord = new StringBuilder((string)arraylist[x]);
            correctWord = guessWord.ToString();
            index = x;
        }

        public void setWordImage(ArrayList arraylist)
        {
            System.Drawing.Bitmap imagePath = new Bitmap(@"C:\Users\USER\source\repos\07_TaskPerformance_GUI_Evasco\07_TaskPerformance_GUI_Evasco\" + (string)arraylist[index]);
            pictureBox1.Image = imagePath;
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
        }


        public void putBlankOnWord(StringBuilder word, ArrayList arraylist)
        {
            for (int loop = 0; loop < arraylist.Count; loop += 1)
            {
                word[(int)arraylist[loop]] = '_';
            }
        }


        public bool CheckIndexMin(int min, int currIndex)
        {
            if(currIndex == min)
            {
                return true;
            }
            return false;
        }

        public bool CheckIndexMax(int max, int currIndex)
        {
            if (currIndex == max)
            {
                return true;
            }
            return false;
        }

        public void GenerateGame()
        {
            currentIndex = 0;
            lbl_result.Text = " ";
            getRandomWord(words);
            generateRandomNumbersToArrayList(guessWord.Length, blankIndexes);
            putBlankOnWord(guessWord, blankIndexes);
            setWordImage(imageLocations);
            lbl_strippedWord.Text = guessWord.ToString();
        }



        private void button1_Click(object sender, EventArgs e)
        {
            letterTracker('a', blankIndexes, guessWord);
            changeGuessWordLabel(guessWord.ToString());
            currentIndex += 1;
        }

        private void btn_letterB_Click(object sender, EventArgs e)
        {
            letterTracker('b', blankIndexes, guessWord);
            changeGuessWordLabel(guessWord.ToString());
            currentIndex += 1;
        }

        private void btn_letterC_Click(object sender, EventArgs e)
        {
            letterTracker('c', blankIndexes, guessWord);
            changeGuessWordLabel(guessWord.ToString());
            currentIndex += 1;
        }

        private void btn_letterD_Click(object sender, EventArgs e)
        {
            letterTracker('d', blankIndexes, guessWord);
            changeGuessWordLabel(guessWord.ToString());
            currentIndex += 1;
        }

        private void btn_letterE_Click(object sender, EventArgs e)
        {
            letterTracker('e', blankIndexes, guessWord);
            changeGuessWordLabel(guessWord.ToString());
            currentIndex += 1;
        }

        private void btn_letterF_Click(object sender, EventArgs e)
        {
            letterTracker('f', blankIndexes, guessWord);
            changeGuessWordLabel(guessWord.ToString());
            currentIndex += 1;
        }

        private void btn_letterG_Click(object sender, EventArgs e)
        {
            letterTracker('g', blankIndexes, guessWord);
            changeGuessWordLabel(guessWord.ToString());
            currentIndex += 1;
        }

        private void btn_letterH_Click(object sender, EventArgs e)
        {
            letterTracker('h', blankIndexes, guessWord);
            changeGuessWordLabel(guessWord.ToString());
            currentIndex += 1;
        }

        private void btn_letterI_Click(object sender, EventArgs e)
        {
            letterTracker('i', blankIndexes, guessWord);
            changeGuessWordLabel(guessWord.ToString());
            currentIndex += 1;
        }

        private void btn_letterJ_Click(object sender, EventArgs e)
        {
            letterTracker('j', blankIndexes, guessWord);
            changeGuessWordLabel(guessWord.ToString());
            currentIndex += 1;
        }

        private void btn_letterK_Click(object sender, EventArgs e)
        {
            letterTracker('k', blankIndexes, guessWord);
            changeGuessWordLabel(guessWord.ToString());
            currentIndex += 1;
        }

        private void btn_letterL_Click(object sender, EventArgs e)
        {
            letterTracker('l', blankIndexes, guessWord);
            changeGuessWordLabel(guessWord.ToString());
            currentIndex += 1;
        }

        private void btn_letterM_Click(object sender, EventArgs e)
        {
            letterTracker('m', blankIndexes, guessWord);
            changeGuessWordLabel(guessWord.ToString());
            currentIndex += 1;
        }

        private void btn_letterN_Click(object sender, EventArgs e)
        {
            letterTracker('n', blankIndexes, guessWord);
            changeGuessWordLabel(guessWord.ToString());
            currentIndex += 1;
        }

        private void btn_letterO_Click(object sender, EventArgs e)
        {
            letterTracker('o', blankIndexes, guessWord);
            changeGuessWordLabel(guessWord.ToString());
            currentIndex += 1;
        }

        private void btn_letterP_Click(object sender, EventArgs e)
        {
            letterTracker('p', blankIndexes, guessWord);
            changeGuessWordLabel(guessWord.ToString());
            currentIndex += 1;
        }

        private void btn_letterQ_Click(object sender, EventArgs e)
        {
            letterTracker('q', blankIndexes, guessWord);
            changeGuessWordLabel(guessWord.ToString());
            currentIndex += 1;
        }

        private void btn_letterR_Click(object sender, EventArgs e)
        {
            letterTracker('r', blankIndexes, guessWord);
            changeGuessWordLabel(guessWord.ToString());
            currentIndex += 1;
        }

        private void btn_letterS_Click(object sender, EventArgs e)
        {
            letterTracker('s', blankIndexes, guessWord);
            changeGuessWordLabel(guessWord.ToString());
            currentIndex += 1;
        }

        private void btn_letterT_Click(object sender, EventArgs e)
        {
            letterTracker('t', blankIndexes, guessWord);
            changeGuessWordLabel(guessWord.ToString());
            currentIndex += 1;
        }

        private void btn_letterU_Click(object sender, EventArgs e)
        {
            letterTracker('u', blankIndexes, guessWord);
            changeGuessWordLabel(guessWord.ToString());
            currentIndex += 1;
        }

        private void btn_letterV_Click(object sender, EventArgs e)
        {
            letterTracker('v', blankIndexes, guessWord);
            changeGuessWordLabel(guessWord.ToString());
            currentIndex += 1;
        }

        private void btn_letterW_Click(object sender, EventArgs e)
        {
            letterTracker('w', blankIndexes, guessWord);
            changeGuessWordLabel(guessWord.ToString());
            currentIndex += 1;
        }

        private void btn_letterX_Click(object sender, EventArgs e)
        {
            letterTracker('x', blankIndexes, guessWord);
            changeGuessWordLabel(guessWord.ToString());
            currentIndex += 1;
        }

        private void btn_letterY_Click(object sender, EventArgs e)
        {
            letterTracker('y', blankIndexes, guessWord);
            changeGuessWordLabel(guessWord.ToString());
            currentIndex += 1;
        }

        private void btn_letterZ_Click(object sender, EventArgs e)
        {
            letterTracker('z', blankIndexes, guessWord);
            changeGuessWordLabel(guessWord.ToString());
            currentIndex += 1;
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            currentIndex -= 1;
            letterTracker('_', blankIndexes, guessWord);
            changeGuessWordLabel(guessWord.ToString());
        }

        private void btn_submit_Click(object sender, EventArgs e)
        {
            if (lbl_strippedWord.Text.ToString().ToLower() == correctWord.ToLower())
            {
                lbl_result.Text = "You are correct!";
                btn_next.Enabled = true;
            }
            else
            {
                lbl_result.Text = "You are incorrect";
                btn_next.Enabled = false;

            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_next_Click(object sender, EventArgs e)
        {
            GenerateGame();
        }
    }
}
