﻿namespace _07_TaskPerformance_GUI_Evasco
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_strippedWord = new System.Windows.Forms.Label();
            this.btn_letterA = new System.Windows.Forms.Button();
            this.btn_letterB = new System.Windows.Forms.Button();
            this.btn_letterC = new System.Windows.Forms.Button();
            this.btn_letterD = new System.Windows.Forms.Button();
            this.btn_letterE = new System.Windows.Forms.Button();
            this.btn_letterF = new System.Windows.Forms.Button();
            this.btn_letterG = new System.Windows.Forms.Button();
            this.btn_letterH = new System.Windows.Forms.Button();
            this.btn_letterI = new System.Windows.Forms.Button();
            this.btn_letterJ = new System.Windows.Forms.Button();
            this.btn_letterK = new System.Windows.Forms.Button();
            this.btn_letterL = new System.Windows.Forms.Button();
            this.btn_letterM = new System.Windows.Forms.Button();
            this.btn_letterN = new System.Windows.Forms.Button();
            this.btn_letterO = new System.Windows.Forms.Button();
            this.btn_letterP = new System.Windows.Forms.Button();
            this.btn_letterQ = new System.Windows.Forms.Button();
            this.btn_letterR = new System.Windows.Forms.Button();
            this.btn_letterS = new System.Windows.Forms.Button();
            this.btn_letterT = new System.Windows.Forms.Button();
            this.btn_letterU = new System.Windows.Forms.Button();
            this.btn_letterV = new System.Windows.Forms.Button();
            this.btn_letterW = new System.Windows.Forms.Button();
            this.btn_letterX = new System.Windows.Forms.Button();
            this.btn_letterY = new System.Windows.Forms.Button();
            this.btn_letterZ = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.btn_submit = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btn_next = new System.Windows.Forms.Button();
            this.lbl_result = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(29, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 25);
            this.label1.TabIndex = 0;
            // 
            // lbl_strippedWord
            // 
            this.lbl_strippedWord.AutoSize = true;
            this.lbl_strippedWord.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_strippedWord.Location = new System.Drawing.Point(194, 235);
            this.lbl_strippedWord.Name = "lbl_strippedWord";
            this.lbl_strippedWord.Size = new System.Drawing.Size(60, 24);
            this.lbl_strippedWord.TabIndex = 2;
            this.lbl_strippedWord.Text = "N_m_";
            // 
            // btn_letterA
            // 
            this.btn_letterA.Location = new System.Drawing.Point(20, 275);
            this.btn_letterA.Name = "btn_letterA";
            this.btn_letterA.Size = new System.Drawing.Size(30, 27);
            this.btn_letterA.TabIndex = 3;
            this.btn_letterA.Text = "A";
            this.btn_letterA.UseVisualStyleBackColor = true;
            this.btn_letterA.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_letterB
            // 
            this.btn_letterB.Location = new System.Drawing.Point(56, 275);
            this.btn_letterB.Name = "btn_letterB";
            this.btn_letterB.Size = new System.Drawing.Size(30, 27);
            this.btn_letterB.TabIndex = 4;
            this.btn_letterB.Text = "B";
            this.btn_letterB.UseVisualStyleBackColor = true;
            this.btn_letterB.Click += new System.EventHandler(this.btn_letterB_Click);
            // 
            // btn_letterC
            // 
            this.btn_letterC.Location = new System.Drawing.Point(92, 275);
            this.btn_letterC.Name = "btn_letterC";
            this.btn_letterC.Size = new System.Drawing.Size(30, 27);
            this.btn_letterC.TabIndex = 5;
            this.btn_letterC.Text = "C";
            this.btn_letterC.UseVisualStyleBackColor = true;
            this.btn_letterC.Click += new System.EventHandler(this.btn_letterC_Click);
            // 
            // btn_letterD
            // 
            this.btn_letterD.Location = new System.Drawing.Point(128, 275);
            this.btn_letterD.Name = "btn_letterD";
            this.btn_letterD.Size = new System.Drawing.Size(30, 27);
            this.btn_letterD.TabIndex = 6;
            this.btn_letterD.Text = "D";
            this.btn_letterD.UseVisualStyleBackColor = true;
            this.btn_letterD.Click += new System.EventHandler(this.btn_letterD_Click);
            // 
            // btn_letterE
            // 
            this.btn_letterE.Location = new System.Drawing.Point(164, 275);
            this.btn_letterE.Name = "btn_letterE";
            this.btn_letterE.Size = new System.Drawing.Size(30, 27);
            this.btn_letterE.TabIndex = 7;
            this.btn_letterE.Text = "E";
            this.btn_letterE.UseVisualStyleBackColor = true;
            this.btn_letterE.Click += new System.EventHandler(this.btn_letterE_Click);
            // 
            // btn_letterF
            // 
            this.btn_letterF.Location = new System.Drawing.Point(200, 275);
            this.btn_letterF.Name = "btn_letterF";
            this.btn_letterF.Size = new System.Drawing.Size(30, 27);
            this.btn_letterF.TabIndex = 8;
            this.btn_letterF.Text = "F";
            this.btn_letterF.UseVisualStyleBackColor = true;
            this.btn_letterF.Click += new System.EventHandler(this.btn_letterF_Click);
            // 
            // btn_letterG
            // 
            this.btn_letterG.Location = new System.Drawing.Point(236, 275);
            this.btn_letterG.Name = "btn_letterG";
            this.btn_letterG.Size = new System.Drawing.Size(30, 27);
            this.btn_letterG.TabIndex = 9;
            this.btn_letterG.Text = "G";
            this.btn_letterG.UseVisualStyleBackColor = true;
            this.btn_letterG.Click += new System.EventHandler(this.btn_letterG_Click);
            // 
            // btn_letterH
            // 
            this.btn_letterH.Location = new System.Drawing.Point(272, 275);
            this.btn_letterH.Name = "btn_letterH";
            this.btn_letterH.Size = new System.Drawing.Size(30, 27);
            this.btn_letterH.TabIndex = 10;
            this.btn_letterH.Text = "H";
            this.btn_letterH.UseVisualStyleBackColor = true;
            this.btn_letterH.Click += new System.EventHandler(this.btn_letterH_Click);
            // 
            // btn_letterI
            // 
            this.btn_letterI.Location = new System.Drawing.Point(308, 275);
            this.btn_letterI.Name = "btn_letterI";
            this.btn_letterI.Size = new System.Drawing.Size(30, 27);
            this.btn_letterI.TabIndex = 11;
            this.btn_letterI.Text = "I";
            this.btn_letterI.UseVisualStyleBackColor = true;
            this.btn_letterI.Click += new System.EventHandler(this.btn_letterI_Click);
            // 
            // btn_letterJ
            // 
            this.btn_letterJ.Location = new System.Drawing.Point(344, 275);
            this.btn_letterJ.Name = "btn_letterJ";
            this.btn_letterJ.Size = new System.Drawing.Size(30, 27);
            this.btn_letterJ.TabIndex = 12;
            this.btn_letterJ.Text = "J";
            this.btn_letterJ.UseVisualStyleBackColor = true;
            this.btn_letterJ.Click += new System.EventHandler(this.btn_letterJ_Click);
            // 
            // btn_letterK
            // 
            this.btn_letterK.Location = new System.Drawing.Point(380, 275);
            this.btn_letterK.Name = "btn_letterK";
            this.btn_letterK.Size = new System.Drawing.Size(30, 27);
            this.btn_letterK.TabIndex = 13;
            this.btn_letterK.Text = "K";
            this.btn_letterK.UseVisualStyleBackColor = true;
            this.btn_letterK.Click += new System.EventHandler(this.btn_letterK_Click);
            // 
            // btn_letterL
            // 
            this.btn_letterL.Location = new System.Drawing.Point(416, 275);
            this.btn_letterL.Name = "btn_letterL";
            this.btn_letterL.Size = new System.Drawing.Size(30, 27);
            this.btn_letterL.TabIndex = 14;
            this.btn_letterL.Text = "L";
            this.btn_letterL.UseVisualStyleBackColor = true;
            this.btn_letterL.Click += new System.EventHandler(this.btn_letterL_Click);
            // 
            // btn_letterM
            // 
            this.btn_letterM.Location = new System.Drawing.Point(20, 308);
            this.btn_letterM.Name = "btn_letterM";
            this.btn_letterM.Size = new System.Drawing.Size(30, 27);
            this.btn_letterM.TabIndex = 15;
            this.btn_letterM.Text = "M";
            this.btn_letterM.UseVisualStyleBackColor = true;
            this.btn_letterM.Click += new System.EventHandler(this.btn_letterM_Click);
            // 
            // btn_letterN
            // 
            this.btn_letterN.Location = new System.Drawing.Point(56, 308);
            this.btn_letterN.Name = "btn_letterN";
            this.btn_letterN.Size = new System.Drawing.Size(30, 27);
            this.btn_letterN.TabIndex = 16;
            this.btn_letterN.Text = "N";
            this.btn_letterN.UseVisualStyleBackColor = true;
            this.btn_letterN.Click += new System.EventHandler(this.btn_letterN_Click);
            // 
            // btn_letterO
            // 
            this.btn_letterO.Location = new System.Drawing.Point(92, 308);
            this.btn_letterO.Name = "btn_letterO";
            this.btn_letterO.Size = new System.Drawing.Size(30, 27);
            this.btn_letterO.TabIndex = 17;
            this.btn_letterO.Text = "O";
            this.btn_letterO.UseVisualStyleBackColor = true;
            this.btn_letterO.Click += new System.EventHandler(this.btn_letterO_Click);
            // 
            // btn_letterP
            // 
            this.btn_letterP.Location = new System.Drawing.Point(128, 308);
            this.btn_letterP.Name = "btn_letterP";
            this.btn_letterP.Size = new System.Drawing.Size(30, 27);
            this.btn_letterP.TabIndex = 18;
            this.btn_letterP.Text = "P";
            this.btn_letterP.UseVisualStyleBackColor = true;
            this.btn_letterP.Click += new System.EventHandler(this.btn_letterP_Click);
            // 
            // btn_letterQ
            // 
            this.btn_letterQ.Location = new System.Drawing.Point(164, 308);
            this.btn_letterQ.Name = "btn_letterQ";
            this.btn_letterQ.Size = new System.Drawing.Size(30, 27);
            this.btn_letterQ.TabIndex = 19;
            this.btn_letterQ.Text = "Q";
            this.btn_letterQ.UseVisualStyleBackColor = true;
            this.btn_letterQ.Click += new System.EventHandler(this.btn_letterQ_Click);
            // 
            // btn_letterR
            // 
            this.btn_letterR.Location = new System.Drawing.Point(198, 308);
            this.btn_letterR.Name = "btn_letterR";
            this.btn_letterR.Size = new System.Drawing.Size(30, 27);
            this.btn_letterR.TabIndex = 20;
            this.btn_letterR.Text = "R";
            this.btn_letterR.UseVisualStyleBackColor = true;
            this.btn_letterR.Click += new System.EventHandler(this.btn_letterR_Click);
            // 
            // btn_letterS
            // 
            this.btn_letterS.Location = new System.Drawing.Point(236, 308);
            this.btn_letterS.Name = "btn_letterS";
            this.btn_letterS.Size = new System.Drawing.Size(30, 27);
            this.btn_letterS.TabIndex = 21;
            this.btn_letterS.Text = "S";
            this.btn_letterS.UseVisualStyleBackColor = true;
            this.btn_letterS.Click += new System.EventHandler(this.btn_letterS_Click);
            // 
            // btn_letterT
            // 
            this.btn_letterT.Location = new System.Drawing.Point(272, 308);
            this.btn_letterT.Name = "btn_letterT";
            this.btn_letterT.Size = new System.Drawing.Size(30, 27);
            this.btn_letterT.TabIndex = 22;
            this.btn_letterT.Text = "T";
            this.btn_letterT.UseVisualStyleBackColor = true;
            this.btn_letterT.Click += new System.EventHandler(this.btn_letterT_Click);
            // 
            // btn_letterU
            // 
            this.btn_letterU.Location = new System.Drawing.Point(308, 308);
            this.btn_letterU.Name = "btn_letterU";
            this.btn_letterU.Size = new System.Drawing.Size(30, 27);
            this.btn_letterU.TabIndex = 23;
            this.btn_letterU.Text = "U";
            this.btn_letterU.UseVisualStyleBackColor = true;
            this.btn_letterU.Click += new System.EventHandler(this.btn_letterU_Click);
            // 
            // btn_letterV
            // 
            this.btn_letterV.Location = new System.Drawing.Point(344, 308);
            this.btn_letterV.Name = "btn_letterV";
            this.btn_letterV.Size = new System.Drawing.Size(30, 27);
            this.btn_letterV.TabIndex = 24;
            this.btn_letterV.Text = "V";
            this.btn_letterV.UseVisualStyleBackColor = true;
            this.btn_letterV.Click += new System.EventHandler(this.btn_letterV_Click);
            // 
            // btn_letterW
            // 
            this.btn_letterW.Location = new System.Drawing.Point(380, 308);
            this.btn_letterW.Name = "btn_letterW";
            this.btn_letterW.Size = new System.Drawing.Size(30, 27);
            this.btn_letterW.TabIndex = 25;
            this.btn_letterW.Text = "W";
            this.btn_letterW.UseVisualStyleBackColor = true;
            this.btn_letterW.Click += new System.EventHandler(this.btn_letterW_Click);
            // 
            // btn_letterX
            // 
            this.btn_letterX.Location = new System.Drawing.Point(416, 308);
            this.btn_letterX.Name = "btn_letterX";
            this.btn_letterX.Size = new System.Drawing.Size(30, 27);
            this.btn_letterX.TabIndex = 26;
            this.btn_letterX.Text = "X";
            this.btn_letterX.UseVisualStyleBackColor = true;
            this.btn_letterX.Click += new System.EventHandler(this.btn_letterX_Click);
            // 
            // btn_letterY
            // 
            this.btn_letterY.Location = new System.Drawing.Point(20, 339);
            this.btn_letterY.Name = "btn_letterY";
            this.btn_letterY.Size = new System.Drawing.Size(30, 27);
            this.btn_letterY.TabIndex = 27;
            this.btn_letterY.Text = "Y";
            this.btn_letterY.UseVisualStyleBackColor = true;
            this.btn_letterY.Click += new System.EventHandler(this.btn_letterY_Click);
            // 
            // btn_letterZ
            // 
            this.btn_letterZ.Location = new System.Drawing.Point(56, 339);
            this.btn_letterZ.Name = "btn_letterZ";
            this.btn_letterZ.Size = new System.Drawing.Size(30, 27);
            this.btn_letterZ.TabIndex = 28;
            this.btn_letterZ.Text = "Z";
            this.btn_letterZ.UseVisualStyleBackColor = true;
            this.btn_letterZ.Click += new System.EventHandler(this.btn_letterZ_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(308, 339);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(66, 27);
            this.btn_delete.TabIndex = 29;
            this.btn_delete.Text = "DELETE";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // btn_submit
            // 
            this.btn_submit.Location = new System.Drawing.Point(380, 339);
            this.btn_submit.Name = "btn_submit";
            this.btn_submit.Size = new System.Drawing.Size(66, 27);
            this.btn_submit.TabIndex = 30;
            this.btn_submit.Text = "SUBMIT";
            this.btn_submit.UseVisualStyleBackColor = true;
            this.btn_submit.Click += new System.EventHandler(this.btn_submit_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(107, 57);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(231, 175);
            this.pictureBox1.TabIndex = 31;
            this.pictureBox1.TabStop = false;
            // 
            // btn_next
            // 
            this.btn_next.Location = new System.Drawing.Point(236, 342);
            this.btn_next.Name = "btn_next";
            this.btn_next.Size = new System.Drawing.Size(66, 23);
            this.btn_next.TabIndex = 32;
            this.btn_next.Text = "NEXT";
            this.btn_next.UseVisualStyleBackColor = true;
            this.btn_next.Click += new System.EventHandler(this.btn_next_Click);
            // 
            // lbl_result
            // 
            this.lbl_result.AutoSize = true;
            this.lbl_result.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_result.Location = new System.Drawing.Point(158, 10);
            this.lbl_result.Name = "lbl_result";
            this.lbl_result.Size = new System.Drawing.Size(0, 24);
            this.lbl_result.TabIndex = 33;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(459, 390);
            this.Controls.Add(this.lbl_result);
            this.Controls.Add(this.btn_next);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btn_submit);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_letterZ);
            this.Controls.Add(this.btn_letterY);
            this.Controls.Add(this.btn_letterX);
            this.Controls.Add(this.btn_letterW);
            this.Controls.Add(this.btn_letterV);
            this.Controls.Add(this.btn_letterU);
            this.Controls.Add(this.btn_letterT);
            this.Controls.Add(this.btn_letterS);
            this.Controls.Add(this.btn_letterR);
            this.Controls.Add(this.btn_letterQ);
            this.Controls.Add(this.btn_letterP);
            this.Controls.Add(this.btn_letterO);
            this.Controls.Add(this.btn_letterN);
            this.Controls.Add(this.btn_letterM);
            this.Controls.Add(this.btn_letterL);
            this.Controls.Add(this.btn_letterK);
            this.Controls.Add(this.btn_letterJ);
            this.Controls.Add(this.btn_letterI);
            this.Controls.Add(this.btn_letterH);
            this.Controls.Add(this.btn_letterG);
            this.Controls.Add(this.btn_letterF);
            this.Controls.Add(this.btn_letterE);
            this.Controls.Add(this.btn_letterD);
            this.Controls.Add(this.btn_letterC);
            this.Controls.Add(this.btn_letterB);
            this.Controls.Add(this.btn_letterA);
            this.Controls.Add(this.lbl_strippedWord);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "07_TP_EVASCO: Word Guessing Game";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_strippedWord;
        private System.Windows.Forms.Button btn_letterA;
        private System.Windows.Forms.Button btn_letterB;
        private System.Windows.Forms.Button btn_letterC;
        private System.Windows.Forms.Button btn_letterD;
        private System.Windows.Forms.Button btn_letterE;
        private System.Windows.Forms.Button btn_letterF;
        private System.Windows.Forms.Button btn_letterG;
        private System.Windows.Forms.Button btn_letterH;
        private System.Windows.Forms.Button btn_letterI;
        private System.Windows.Forms.Button btn_letterJ;
        private System.Windows.Forms.Button btn_letterK;
        private System.Windows.Forms.Button btn_letterL;
        private System.Windows.Forms.Button btn_letterM;
        private System.Windows.Forms.Button btn_letterN;
        private System.Windows.Forms.Button btn_letterO;
        private System.Windows.Forms.Button btn_letterP;
        private System.Windows.Forms.Button btn_letterQ;
        private System.Windows.Forms.Button btn_letterR;
        private System.Windows.Forms.Button btn_letterS;
        private System.Windows.Forms.Button btn_letterT;
        private System.Windows.Forms.Button btn_letterU;
        private System.Windows.Forms.Button btn_letterV;
        private System.Windows.Forms.Button btn_letterW;
        private System.Windows.Forms.Button btn_letterX;
        private System.Windows.Forms.Button btn_letterY;
        private System.Windows.Forms.Button btn_letterZ;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.Button btn_submit;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btn_next;
        private System.Windows.Forms.Label lbl_result;
    }
}

