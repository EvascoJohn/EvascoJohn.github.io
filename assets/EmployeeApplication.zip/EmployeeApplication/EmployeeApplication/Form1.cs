﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EmployeeNamespace;

namespace EmployeeApplication
{
    public partial class frmEmployeeDatabase : Form
    {

        public frmEmployeeDatabase()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            dataGridView1.ColumnCount = 4;

            dataGridView1.Columns[0].Name = "id";
            dataGridView1.Columns[1].Name = "firstname";
            dataGridView1.Columns[2].Name = "lastname";
            dataGridView1.Columns[3].Name = "position";

        }

        public bool checkTextBoxesIfNotEmpty()
        {
            TextBox[] list = new TextBox[] { textBox1, textBox2, textBox3, textBox4 };
            for(int i = 0; i < list.Length; i += 1)
            {
                if (list[i].Text == "" || list[i].Text == String.Empty)
                {
                    return true;
                }
            }

            return false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(checkTextBoxesIfNotEmpty() == false)
            {
                Employee employee = new Employee(textBox1.Text, textBox2.Text, textBox3.Text, textBox4.Text);
                string[] dataRow = employee.getAsList();
                dataGridView1.Rows.Add(dataRow);

                textBox1.Text = String.Empty;
                textBox2.Text = String.Empty;
                textBox3.Text = String.Empty;
                textBox4.Text = String.Empty;
            }

        }

    }
}


namespace EmployeeNamespace
{
    class Employee
    {
        string id, firstname, lastname, position;

        //Overload method.
        public Employee(string id, string firstname, string lastname, string position)
        {
            this.id = id; this.firstname = firstname; this.lastname = lastname; this.position = position;
        }
        //Overload method.
        public Employee()
        {

        }


        //Encapsulations.
        public string ID
        {
            get { return this.id; }
            set { this.id = value; }
        }
        public string Firstname
        {
            get { return this.firstname; }
            set { this.firstname = value; }
        }

        public string Lastname
        {
            get { return this.Lastname; }
            set { this.Lastname = value; }
        }

        public string Position
        {
            get { return this.position; }
            set { this.position = value; }
        }

        public string[] getAsList()
        {
            return new string[] { this.id, this.firstname, this.lastname, this.position};
        }

    }
}