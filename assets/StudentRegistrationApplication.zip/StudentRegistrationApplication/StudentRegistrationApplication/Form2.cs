﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentRegistrationApplication
{

    public partial class Form2 : Form
    {
        public Form2(string passedFirstName, string passedMiddleName, string passedLastName, string passedGender, string passedDateOfBirth)
        {
            InitializeComponent();
            updateLabels(passedFirstName, passedMiddleName, passedLastName, passedGender, passedDateOfBirth);
        }

        private void updateLabels(string passedFirstName, string passedMiddleName, string passedLastName,string gender, String dateOfBirth)
        {
            label1.Text = "Name:"+passedFirstName + " " + passedMiddleName + " " + passedLastName;
            label2.Text = "Gender:" + gender;
            label3.Text = "Date of birth:" + dateOfBirth;
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
