﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentRegistrationApplication
{
    public partial class FirstWindow : Form
    {
        public static FirstWindow firstWindow;
        public FirstWindow()
        {
            InitializeComponent();
            firstWindow = this;
            for (int i = 1; i <= 31; i++)
            {
                comboBoxDate.Items.Add(i);
            }
            for (int i = 1; i <= 12; i++)
            {
                comboBoxMonth.Items.Add(i);
            }
            for (int i = 1900; i <= 2022; i++)
            {
                comboBoxYear.Items.Add(i);
            }
        }



        private void buttonRegister_Click(object sender, EventArgs e)
        {
            string gender;
            string dateOfBirth;
            if (radioButtonMale.Checked)
            {
                gender = "Male";
            }
            else if (radioButtonFemale.Checked)
            {
                gender = "Female";
            }
            else {
                gender = "None";
            }
            dateOfBirth = comboBoxDate.Text +"/"+ comboBoxMonth.Text + "/" + comboBoxYear.Text;
            Form2 second_window = new Form2(txtBoxFirstName.Text, txtBoxMiddleName.Text, txtBoxLastName.Text, gender, dateOfBirth);
            second_window.Show();
        }

    }
}
