﻿namespace PayrollProg_Evasco
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.txtbox_employee_employeeName = new System.Windows.Forms.TextBox();
            this.lbl_employee_employeeName = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lbl_employee_hoursWorked = new System.Windows.Forms.Label();
            this.numrc_employee_hoursWorked = new System.Windows.Forms.NumericUpDown();
            this.cmbobx_employee_occupation = new System.Windows.Forms.ComboBox();
            this.lbl_employee_occupation = new System.Windows.Forms.Label();
            this.btn_employee_add = new System.Windows.Forms.Button();
            this.btn_employee_update = new System.Windows.Forms.Button();
            this.btn_employee_delete = new System.Windows.Forms.Button();
            this.btn_occupation_delete = new System.Windows.Forms.Button();
            this.btn_occupation_update = new System.Windows.Forms.Button();
            this.btn_occupation_add = new System.Windows.Forms.Button();
            this.cmbobx_occupation_occupation = new System.Windows.Forms.ComboBox();
            this.txtbox_occupation_occupationName = new System.Windows.Forms.TextBox();
            this.lbl_occupation_occupationName = new System.Windows.Forms.Label();
            this.txtbox_occupation_payPerHour = new System.Windows.Forms.TextBox();
            this.lbl_occupation_payPerHour = new System.Windows.Forms.Label();
            this.lbl_occupation_occupation = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numrc_employee_hoursWorked)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlDarkDark;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(11, 242);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(663, 392);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // txtbox_employee_employeeName
            // 
            this.txtbox_employee_employeeName.Location = new System.Drawing.Point(95, 27);
            this.txtbox_employee_employeeName.Name = "txtbox_employee_employeeName";
            this.txtbox_employee_employeeName.Size = new System.Drawing.Size(176, 20);
            this.txtbox_employee_employeeName.TabIndex = 1;
            // 
            // lbl_employee_employeeName
            // 
            this.lbl_employee_employeeName.AutoSize = true;
            this.lbl_employee_employeeName.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_employee_employeeName.Location = new System.Drawing.Point(6, 30);
            this.lbl_employee_employeeName.Name = "lbl_employee_employeeName";
            this.lbl_employee_employeeName.Size = new System.Drawing.Size(86, 14);
            this.lbl_employee_employeeName.TabIndex = 7;
            this.lbl_employee_employeeName.Text = "Employee Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(100, 127);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 13);
            this.label2.TabIndex = 8;
            // 
            // lbl_employee_hoursWorked
            // 
            this.lbl_employee_hoursWorked.AutoSize = true;
            this.lbl_employee_hoursWorked.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_employee_hoursWorked.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_employee_hoursWorked.Location = new System.Drawing.Point(9, 114);
            this.lbl_employee_hoursWorked.Name = "lbl_employee_hoursWorked";
            this.lbl_employee_hoursWorked.Size = new System.Drawing.Size(79, 14);
            this.lbl_employee_hoursWorked.TabIndex = 9;
            this.lbl_employee_hoursWorked.Text = "Hours Worked:";
            // 
            // numrc_employee_hoursWorked
            // 
            this.numrc_employee_hoursWorked.Location = new System.Drawing.Point(96, 111);
            this.numrc_employee_hoursWorked.Name = "numrc_employee_hoursWorked";
            this.numrc_employee_hoursWorked.Size = new System.Drawing.Size(67, 20);
            this.numrc_employee_hoursWorked.TabIndex = 10;
            // 
            // cmbobx_employee_occupation
            // 
            this.cmbobx_employee_occupation.FormattingEnabled = true;
            this.cmbobx_employee_occupation.Location = new System.Drawing.Point(96, 69);
            this.cmbobx_employee_occupation.Name = "cmbobx_employee_occupation";
            this.cmbobx_employee_occupation.Size = new System.Drawing.Size(176, 21);
            this.cmbobx_employee_occupation.TabIndex = 11;
            // 
            // lbl_employee_occupation
            // 
            this.lbl_employee_occupation.AutoSize = true;
            this.lbl_employee_occupation.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_employee_occupation.Location = new System.Drawing.Point(6, 73);
            this.lbl_employee_occupation.Name = "lbl_employee_occupation";
            this.lbl_employee_occupation.Size = new System.Drawing.Size(65, 14);
            this.lbl_employee_occupation.TabIndex = 12;
            this.lbl_employee_occupation.Text = "Occupation:";
            // 
            // btn_employee_add
            // 
            this.btn_employee_add.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btn_employee_add.Location = new System.Drawing.Point(6, 181);
            this.btn_employee_add.Name = "btn_employee_add";
            this.btn_employee_add.Size = new System.Drawing.Size(75, 23);
            this.btn_employee_add.TabIndex = 4;
            this.btn_employee_add.Text = "Add";
            this.btn_employee_add.UseVisualStyleBackColor = false;
            this.btn_employee_add.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_employee_update
            // 
            this.btn_employee_update.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btn_employee_update.Location = new System.Drawing.Point(103, 181);
            this.btn_employee_update.Name = "btn_employee_update";
            this.btn_employee_update.Size = new System.Drawing.Size(75, 23);
            this.btn_employee_update.TabIndex = 5;
            this.btn_employee_update.Text = "Update";
            this.btn_employee_update.UseVisualStyleBackColor = false;
            this.btn_employee_update.Click += new System.EventHandler(this.button2_Click);
            // 
            // btn_employee_delete
            // 
            this.btn_employee_delete.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btn_employee_delete.Location = new System.Drawing.Point(197, 181);
            this.btn_employee_delete.Name = "btn_employee_delete";
            this.btn_employee_delete.Size = new System.Drawing.Size(75, 23);
            this.btn_employee_delete.TabIndex = 6;
            this.btn_employee_delete.Text = "Delete";
            this.btn_employee_delete.UseVisualStyleBackColor = false;
            this.btn_employee_delete.Click += new System.EventHandler(this.button3_Click);
            // 
            // btn_occupation_delete
            // 
            this.btn_occupation_delete.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btn_occupation_delete.Location = new System.Drawing.Point(196, 181);
            this.btn_occupation_delete.Name = "btn_occupation_delete";
            this.btn_occupation_delete.Size = new System.Drawing.Size(75, 23);
            this.btn_occupation_delete.TabIndex = 13;
            this.btn_occupation_delete.Text = "Delete";
            this.btn_occupation_delete.UseVisualStyleBackColor = false;
            this.btn_occupation_delete.Click += new System.EventHandler(this.button4_Click);
            // 
            // btn_occupation_update
            // 
            this.btn_occupation_update.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btn_occupation_update.Location = new System.Drawing.Point(105, 181);
            this.btn_occupation_update.Name = "btn_occupation_update";
            this.btn_occupation_update.Size = new System.Drawing.Size(75, 23);
            this.btn_occupation_update.TabIndex = 14;
            this.btn_occupation_update.Text = "Update";
            this.btn_occupation_update.UseVisualStyleBackColor = false;
            this.btn_occupation_update.Click += new System.EventHandler(this.button5_Click);
            // 
            // btn_occupation_add
            // 
            this.btn_occupation_add.BackColor = System.Drawing.Color.LightSteelBlue;
            this.btn_occupation_add.Location = new System.Drawing.Point(13, 181);
            this.btn_occupation_add.Name = "btn_occupation_add";
            this.btn_occupation_add.Size = new System.Drawing.Size(75, 23);
            this.btn_occupation_add.TabIndex = 15;
            this.btn_occupation_add.Text = "Add";
            this.btn_occupation_add.UseVisualStyleBackColor = false;
            this.btn_occupation_add.Click += new System.EventHandler(this.button6_Click);
            // 
            // cmbobx_occupation_occupation
            // 
            this.cmbobx_occupation_occupation.FormattingEnabled = true;
            this.cmbobx_occupation_occupation.Location = new System.Drawing.Point(114, 111);
            this.cmbobx_occupation_occupation.Name = "cmbobx_occupation_occupation";
            this.cmbobx_occupation_occupation.Size = new System.Drawing.Size(176, 21);
            this.cmbobx_occupation_occupation.TabIndex = 16;
            this.cmbobx_occupation_occupation.SelectionChangeCommitted += new System.EventHandler(this.comboBox2_SelectionChangeCommitted);
            this.cmbobx_occupation_occupation.TextUpdate += new System.EventHandler(this.comboBox2_TextUpdate);
            // 
            // txtbox_occupation_occupationName
            // 
            this.txtbox_occupation_occupationName.Location = new System.Drawing.Point(114, 27);
            this.txtbox_occupation_occupationName.Name = "txtbox_occupation_occupationName";
            this.txtbox_occupation_occupationName.Size = new System.Drawing.Size(176, 20);
            this.txtbox_occupation_occupationName.TabIndex = 17;
            // 
            // lbl_occupation_occupationName
            // 
            this.lbl_occupation_occupationName.AutoSize = true;
            this.lbl_occupation_occupationName.Location = new System.Drawing.Point(15, 33);
            this.lbl_occupation_occupationName.Name = "lbl_occupation_occupationName";
            this.lbl_occupation_occupationName.Size = new System.Drawing.Size(93, 13);
            this.lbl_occupation_occupationName.TabIndex = 18;
            this.lbl_occupation_occupationName.Text = "Occupation Name";
            // 
            // txtbox_occupation_payPerHour
            // 
            this.txtbox_occupation_payPerHour.Location = new System.Drawing.Point(114, 69);
            this.txtbox_occupation_payPerHour.Name = "txtbox_occupation_payPerHour";
            this.txtbox_occupation_payPerHour.Size = new System.Drawing.Size(176, 20);
            this.txtbox_occupation_payPerHour.TabIndex = 19;
            // 
            // lbl_occupation_payPerHour
            // 
            this.lbl_occupation_payPerHour.AutoSize = true;
            this.lbl_occupation_payPerHour.Location = new System.Drawing.Point(18, 71);
            this.lbl_occupation_payPerHour.Name = "lbl_occupation_payPerHour";
            this.lbl_occupation_payPerHour.Size = new System.Drawing.Size(70, 13);
            this.lbl_occupation_payPerHour.TabIndex = 20;
            this.lbl_occupation_payPerHour.Text = "Pay Per Hour";
            // 
            // lbl_occupation_occupation
            // 
            this.lbl_occupation_occupation.AutoSize = true;
            this.lbl_occupation_occupation.Location = new System.Drawing.Point(20, 116);
            this.lbl_occupation_occupation.Name = "lbl_occupation_occupation";
            this.lbl_occupation_occupation.Size = new System.Drawing.Size(62, 13);
            this.lbl_occupation_occupation.TabIndex = 23;
            this.lbl_occupation_occupation.Text = "Occupation";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.LightSlateGray;
            this.groupBox1.Controls.Add(this.txtbox_employee_employeeName);
            this.groupBox1.Controls.Add(this.btn_employee_add);
            this.groupBox1.Controls.Add(this.btn_employee_update);
            this.groupBox1.Controls.Add(this.btn_employee_delete);
            this.groupBox1.Controls.Add(this.lbl_employee_employeeName);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.lbl_employee_hoursWorked);
            this.groupBox1.Controls.Add(this.numrc_employee_hoursWorked);
            this.groupBox1.Controls.Add(this.cmbobx_employee_occupation);
            this.groupBox1.Controls.Add(this.lbl_employee_occupation);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.groupBox1.Location = new System.Drawing.Point(12, 7);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(320, 217);
            this.groupBox1.TabIndex = 24;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Employee";
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.BackColor = System.Drawing.Color.LightSlateGray;
            this.groupBox2.Controls.Add(this.txtbox_occupation_occupationName);
            this.groupBox2.Controls.Add(this.btn_occupation_delete);
            this.groupBox2.Controls.Add(this.lbl_occupation_occupation);
            this.groupBox2.Controls.Add(this.btn_occupation_update);
            this.groupBox2.Controls.Add(this.lbl_occupation_payPerHour);
            this.groupBox2.Controls.Add(this.btn_occupation_add);
            this.groupBox2.Controls.Add(this.txtbox_occupation_payPerHour);
            this.groupBox2.Controls.Add(this.cmbobx_occupation_occupation);
            this.groupBox2.Controls.Add(this.lbl_occupation_occupationName);
            this.groupBox2.Location = new System.Drawing.Point(354, 7);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(320, 217);
            this.groupBox2.TabIndex = 25;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Occupation";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSlateGray;
            this.ClientSize = new System.Drawing.Size(686, 646);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dataGridView1);
            this.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Payroll_Evasco";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numrc_employee_hoursWorked)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox txtbox_employee_employeeName;
        private System.Windows.Forms.Label lbl_employee_employeeName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbl_employee_hoursWorked;
        private System.Windows.Forms.NumericUpDown numrc_employee_hoursWorked;
        private System.Windows.Forms.ComboBox cmbobx_employee_occupation;
        private System.Windows.Forms.Label lbl_employee_occupation;
        private System.Windows.Forms.Button btn_employee_add;
        private System.Windows.Forms.Button btn_employee_update;
        private System.Windows.Forms.Button btn_employee_delete;
        private System.Windows.Forms.Button btn_occupation_delete;
        private System.Windows.Forms.Button btn_occupation_update;
        private System.Windows.Forms.Button btn_occupation_add;
        private System.Windows.Forms.ComboBox cmbobx_occupation_occupation;
        private System.Windows.Forms.TextBox txtbox_occupation_occupationName;
        private System.Windows.Forms.Label lbl_occupation_occupationName;
        private System.Windows.Forms.TextBox txtbox_occupation_payPerHour;
        private System.Windows.Forms.Label lbl_occupation_payPerHour;
        private System.Windows.Forms.Label lbl_occupation_occupation;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
    }
}

