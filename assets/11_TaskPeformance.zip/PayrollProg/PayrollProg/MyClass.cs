﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PayrollProg_Evasco
{
    class Job
    {
        public string JobName { get; set; }
        public double PayPerHour { get; set; }
        public Job(string jobname, double payperhour)
        {
            this.JobName = jobname;
            this.PayPerHour = payperhour;
        }
    }
}
