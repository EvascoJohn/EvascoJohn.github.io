﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PayrollProg_Evasco;


namespace PayrollProg_Evasco
{

    public partial class Form1 : Form
    {

        DataTable datatable = new DataTable();
        List<Job> joblist = new List<Job>();
        int r;
        int current_index_combobox = 0;

        public Form1()
        {
            InitializeComponent();
        }

        //my functions
        private void clear_occupation_entries()
        {
            txtbox_occupation_occupationName.Text = "";
            txtbox_occupation_payPerHour.Text = "";
            cmbobx_occupation_occupation.Text = "";
        }

        //Finds the Peyperhour using JobName.
        private double get_job_pay(string jobname)
        {
            double pay = 0;
            for (int index = 0; index < joblist.Count; index += 1)
            {
                if (joblist[index].JobName == jobname)
                {
                    pay = joblist[index].PayPerHour;
                }
            }
            return pay;
        }

        private void load_jobs()
        {
            cmbobx_occupation_occupation.Items.Clear();                                     
            cmbobx_employee_occupation.Items.Clear();
            for (int index = 0; index < joblist.Count; index += 1)
            {
                cmbobx_employee_occupation.Items.Add(joblist[index].JobName);
                cmbobx_occupation_occupation.Items.Add(joblist[index].JobName);
            }
        }

private void Form1_Load(object sender, EventArgs e)
        {
            //loads
            joblist.Add(new Job("Game Developer", 443));
            joblist.Add(new Job("Data Analyst", 445));
            load_jobs();
            datatable.Columns.Add("Employee Name", typeof(string));
            datatable.Columns.Add("Occupation", typeof(string));
            datatable.Columns.Add("Pay Per Hour", typeof(double));
            datatable.Columns.Add("Hours Worked", typeof(int));
            datatable.Columns.Add("Salary", typeof(double));
            dataGridView1.DataSource = datatable;
        }


        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                r = e.RowIndex;
                DataGridViewRow row = dataGridView1.Rows[r];
                txtbox_employee_employeeName.Text = row.Cells[0].Value.ToString();
                cmbobx_employee_occupation.Text = row.Cells[1].Value.ToString();
                if (row.Cells[3].ToString().Equals(String.Empty))
                {
                    numrc_employee_hoursWorked.Value = Int32.Parse(row.Cells[3].Value.ToString());
                }
            }
            catch{}
        }

        private void comboBox2_SelectionChangeCommitted(object sender, EventArgs e)
        {
            int pay = 0;
            for (int index = 0; index < joblist.Count; index += 1)
            {
                current_index_combobox = index;
                if (joblist[index].JobName == cmbobx_occupation_occupation.SelectedItem.ToString())
                {
                    pay = (int)joblist[index].PayPerHour;
                }

            }
            txtbox_occupation_occupationName.Text = cmbobx_occupation_occupation.SelectedItem.ToString();
            txtbox_occupation_payPerHour.Text = Convert.ToString(pay);
        }

        private void comboBox2_TextUpdate(object sender, EventArgs e)
        {
         
        }


        //employee add button
        private void button1_Click(object sender, EventArgs e)
        {
            double pay = get_job_pay(cmbobx_employee_occupation.Text);
            int hours = (int)numrc_employee_hoursWorked.Value;

            //Adds to a Employee list, then reloads 
            datatable.Rows.Add(txtbox_employee_employeeName.Text, cmbobx_employee_occupation.Text, pay, hours, (hours * pay));
        }

        //employee update button
        private void button2_Click(object sender, EventArgs e)
        {
            DataGridViewRow newDataRow = dataGridView1.Rows[r];
            newDataRow.Cells[0].Value = txtbox_employee_employeeName.Text;
            newDataRow.Cells[1].Value = cmbobx_employee_occupation.Text;
            if (!cmbobx_employee_occupation.Text.Equals(string.Empty))
            {
                newDataRow.Cells[2].Value = get_job_pay(cmbobx_employee_occupation.Text);
            }
            newDataRow.Cells[3].Value = (int)numrc_employee_hoursWorked.Value;
            newDataRow.Cells[4].Value = (int)newDataRow.Cells[3].Value * get_job_pay(newDataRow.Cells[1].Value.ToString());
        }

        //employee delete button
        private void button3_Click(object sender, EventArgs e)
        {
            int index = dataGridView1.CurrentCell.RowIndex;
            dataGridView1.Rows.RemoveAt(index);
        }

        //occupation delete button
        private void button4_Click(object sender, EventArgs e)
        {
            joblist.RemoveAt(current_index_combobox);
            load_jobs();
            clear_occupation_entries();
        }

        //occupation update button
        private void button5_Click(object sender, EventArgs e)
        {
            //updated JobName && PayperHour
            joblist[current_index_combobox].JobName = txtbox_occupation_occupationName.Text;
            joblist[current_index_combobox].PayPerHour = Convert.ToInt32(txtbox_occupation_payPerHour.Text);
            load_jobs();
            clear_occupation_entries();
        }

        //occupation delete button
        private void button6_Click(object sender, EventArgs e)
        {
            if(!txtbox_occupation_occupationName.Text.ToString().Equals(String.Empty) || !txtbox_occupation_occupationName.Text.ToString().Equals(" "))
            {
                joblist.Add(new Job(txtbox_occupation_occupationName.Text, Convert.ToDouble(txtbox_occupation_payPerHour.Text)));
                load_jobs();
            }
            clear_occupation_entries();
        }

    }
}
