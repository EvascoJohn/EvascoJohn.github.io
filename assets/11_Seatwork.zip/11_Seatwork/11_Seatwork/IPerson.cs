﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonInterface
{
    internal interface IPerson
    {
        public int computeAge(int month, int year, int day);
        public void setFullName(string FName, string LName, string MName);
    }
}
