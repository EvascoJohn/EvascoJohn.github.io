﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AccountInterface;

namespace _11_Seatwork
{
    class BankAccount : ICreateAccount, IUpdateAccount { }
}
