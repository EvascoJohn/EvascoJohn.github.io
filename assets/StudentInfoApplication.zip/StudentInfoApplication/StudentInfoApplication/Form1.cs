using StudentNamespace;

namespace StudentInfoApplication
{


    public partial class Form1 : Form
    {


        public Form1()
        {

            InitializeComponent();

        }

        //A method that adds a string simultaneously on 3 list boxes.
        private void addItemsToListBox(StudentInfo stdnt_info, string id, string lastname, string firstname)
        {

            //ID
            listBox1.Items.Add(stdnt_info.StudentID.ToString());
            //Last name
            listBox2.Items.Add(stdnt_info.LastName);
            //First name
            listBox3.Items.Add(stdnt_info.FirstName);

        }

        //Clears text boxes
        private void clearTextBoxes()
        {

            textBox1.Text = string.Empty;
            textBox2.Text = string.Empty;
            textBox3.Text = string.Empty;

        }


        private void button1_Click(object sender, EventArgs e)
        {

            StudentInfo stdnt_info = new StudentInfo();

            stdnt_info.StudentID = textBox1.Text;
            stdnt_info.LastName  = textBox2.Text;
            stdnt_info.FirstName = textBox3.Text;

            if(stdnt_info.StudentID == string.Empty 
               || stdnt_info.LastName == string.Empty 
               ||  stdnt_info.FirstName == string.Empty
               )
            {

                //if one of the text box is empty, the program will do nothing.

            }
            else
            {

                addItemsToListBox(stdnt_info, stdnt_info.StudentID, stdnt_info.LastName, stdnt_info.FirstName);
                clearTextBoxes();

            }

        }
    }


}

namespace StudentNamespace
{

    public class StudentInfo
    {


        private string studentID;
        private string firstName;
        private string lastName;


        //overload constructor
        public StudentInfo()
        {

        }


        //overload constructor
        public StudentInfo(int studentID, string firstname, string lastname)
        {

            StudentID = Convert.ToString(studentID);

        }


        //overload constructor
        public StudentInfo(string studentID, string firstname, string lastname)
        {

            StudentID = studentID;

        }


        //Student ID encapsulation
        public string StudentID
        {

            get
            {

                return this.studentID;

            }
            set
            {

                this.studentID = value;

            }
        }


        //Student first name encapsulation
        public string FirstName
        {

            get
            {

                return this.firstName.ToString();

            }
            set
            {

                this.firstName = value;

            }
        }


        //Student last name encapsulation
        public string LastName
        {

            get
            {

                return this.lastName.ToString();

            }
            set
            {

                this.lastName = value;

            }
        }


    }

    }