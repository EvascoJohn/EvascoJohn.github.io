﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/* 
 * Create an interface named IAccount, Make it a member of the namespace.
 * 
 *      + Account: long
 *      + Name: string
 *      + Balance : double
 *      --------------------------------------------------
 *      + computerAge(int month, int year, int day) : int
 *      + setFullName(int month, int year, int day) : void
 * 
 */

namespace AccountInterface
{
    internal interface IAccount
    {
        public long Account { get; set; }
        public string Name { get; set; }
        public Double Balance { get; set; }
        public void withdraw(double amount);
        public double deposit(double amount);
    }
}