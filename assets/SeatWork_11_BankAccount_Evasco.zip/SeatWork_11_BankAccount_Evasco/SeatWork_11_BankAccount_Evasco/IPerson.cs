﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


/* 
 * Create an interface called IPerson, Make it a member of the namespace, "PersonInterface"
 * 
 *      + computerAge(int month, int year, int day) : int
 *      + setFullName(int month, int year, int day) : void
 * 
 */

namespace PersonInterface
{
    internal interface IPerson
    {
        public int computeAge(int month, int year, int day);
        public void setFullName(string FName, string LName, string MName);
    }
}
