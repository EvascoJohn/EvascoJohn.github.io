﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


/* 
 * Create class named "BankAccount" that implements the interfaces, 
 * "CreateAccount" and IUpdateAccount, import namespace, "AccountInterface" 
 * Make it a member of the namespace, "PersonInterface"
 * 
 */


using AccountInterface;

namespace SeatWork_11_BankAccount_Evasco
{
    class BankAccount : ICreateAccount, IUpdateAccount{}
}
