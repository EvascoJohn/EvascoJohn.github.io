﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace AccountInterface
{
    internal interface IAccount
    {
        public long Account { get; set; }
        public string Name { get; set; }
        public Double Balance { get; set; }
        public void withdraw(double amount);
        public double deposit(double amount);
    }
}