﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//Alexa Tividad

using AccountInterface;

namespace SeatWork_11_BankAccount_Tividad
{
    class BankAccount : ICreateAccount, IUpdateAccount{}
}
